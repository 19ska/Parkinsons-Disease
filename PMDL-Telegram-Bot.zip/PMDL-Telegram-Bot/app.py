#Import from ML
from urllib import request
from flask import *
from flask import render_template
from flask import jsonify
import pickle
import numpy as np

#Sav Files Import
load_model_DT=pickle.load(open('static/Sav_Models/DT_model.sav','rb'))
load_model_KNN=pickle.load(open('static/Sav_Models/KNN_model.sav','rb'))
load_model_RF=pickle.load(open('static/Sav_Models/RF_model.sav','rb'))
load_model_XG=pickle.load(open('static/Sav_Models/GB_model.sav','rb'))

from typing import Final
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
import os
FILE_PATH = os.path.join('src','static/images')
TOKEN: Final ='6161309317:AAE8v7STJuBedd33NnCmtTrGauLFwm0vc1w'
BOT_USERNAME: Final = '@PMDL_bot'

# Lets us use the /start command
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('👋 Hello there! \nI\'m a PDML BOT🤖 abbrevated as Parkionson\'s Diesease Prediction Using Machine Learning Algorithms. \n\n\nOur Servicesfor Prediction of Parkinson\'s Disease,\n\n1). High Accurate ML Algorithms:Know the results instantly using Supervised Machine Learning Algorithms with high accuracy\n\n2). Audio\n\n3). Spiral Drawning:Predict the disease not only using vocal features but also by uploading the spiral drawings. \n\n\n Get Started \n\n/pmdldata : For High Accurate ML Algorithms(Note: You have to Enter the Data)\n\n/pmdlvoice : Send the Audio file to bot in mp3,mp4 format.\n\n/pmdlspiral : Send Spiral Drwanings to the bot in jpeg,jpj format.')


# Lets us use the /help command
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('Try typing anything and I will do my best to respond!')


# Lets us use the /pmdldata command
async def pmdldata_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text('👋 Hello there! \n You have choosed to /pmdldata .\nPlease folle the instructions given below\n\n1).You have to enter the 22 features such as\n\n ->MDVP:Fo(Hz) - Average vocal fundamental frequency\n\n ->MDVP:Fhi(Hz) - Maximum vocal fundamental frequency\n\n ->MDVP:Flo(Hz) - Minimum vocal fundamental frequency\n\n ->MDVP:Jitter(%), MDVP:Jitter(Abs), MDVP:RAP, MDVP:PPQ, Jitter:DDP - Several measures of variation in fundamental frequency\n\n ->MDVP:Shimmer,MDVP:Shimmer(dB),Shimmer:APQ3,Shimmer:APQ5,MDVP:APQ,Shimmer:DDA - Several measures of variation in amplitude\n\n ->NHR, HNR - Two measures of the ratio of noise to tonal components in the voice\n\n ->status - The health status of the subject (one) - Parkinson\'s, (zero) - healthy\n\n ->RPDE, D2 - Two nonlinear dynamical complexity measures\n\n ->DFA - Signal fractal scaling exponent\n\n ->spread1,spread2,PPE - Three nonlinear measures of fundamental frequency variation\n\n\n Important Note\n Enter the data in chat, format is shown below\n\n 100,155,1.23,2.34,3.45......0.76876')

async def pmdlvoice_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(' hi')

def handle_response(text: str) -> str:
    # Create your own response logic
    processed: str = text.lower()
    str_list=processed.split(",")
    print(str_list)
    size = len(str_list)
    if 'hello' in processed:
        return 'Hey there!'

    if 'how are you' in processed:
        return 'I\'m good!'

    if 'i love python' in processed:
        return 'i love JS!'
    if size == 22:
        float_list = []
        for s in str_list:
            try:
                f = float(s)
                float_list.append(f)
                
            except ValueError:
                return'No Characters are allowed:'.format(s)
        #print(float_list)
        #return'hi{}'.format(float_list)
        #write machine Learning code for 22 features
        # changing input data to a numpy array
        input_data = (float_list)
        #print(input_data)
        input_data_as_numpy_array = np.asarray(float_list)

        # reshape the numpy array
        input_data_reshaped = input_data_as_numpy_array.reshape(1,-1)

        # standardize the data
        #std_data = scaler.transform(input_data_reshaped)

        prediction_DT = load_model_DT.predict(input_data_reshaped)
        print(prediction_DT)
        prediction_KNN = load_model_KNN.predict(input_data_reshaped)
        print(prediction_KNN)
        prediction_RF = load_model_RF.predict(input_data_reshaped)
        print(prediction_RF)
        prediction_XG = load_model_XG.predict(input_data_reshaped)
        print(prediction_XG)
        return'Result XG{} KNN{} DT{},RF{}'.format(prediction_XG,prediction_KNN,prediction_DT,prediction_RF)
    if size != 22:
        return 'it has only {} features'.format(size)
    if size > 22:
        return 'it has {} features '.format(size)

    

    return 'I don\'t understand'



async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Get basic info of the incoming message
    message_type: str = update.message.chat.type
    text: str = update.message.text

    # Print a log for debugging
    print(f'User ({update.message.chat.id}) in {message_type}: "{text}"')

    # React to group messages only if users mention the bot directly
    if message_type == 'group':
        # Replace with your bot username
        if BOT_USERNAME in text:
            new_text: str = text.replace(BOT_USERNAME, '').strip()
            response: str = handle_response(new_text)
        else:
            return  # We don't want the bot respond if it's not mentioned in the group
    else:
        response: str = handle_response(text)

    # Reply normal if the message is in private
    print('Bot:', response)
    await update.message.reply_text(response)


# Log errors
async def error(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print(f'Update {update} caused error {context.error}')


# Run the program
if __name__ == '__main__':
    app = Application.builder().token(TOKEN).build()

    # Commands
    app.add_handler(CommandHandler('start', start_command))
    app.add_handler(CommandHandler('help', help_command))
    app.add_handler(CommandHandler('pmdldata', pmdldata_command))

    # Messages
    app.add_handler(MessageHandler(filters.TEXT, handle_message))

    # Log all errors
    app.add_error_handler(error)

    print('Polling...')
    # Run the bot
    app.run_polling(poll_interval=1)













